package roads;

import java.util.Objects;
import java.util.Set;

public class NonemptyRoute extends Route {

	private final Road firstLeg;
	private final Route continuation;
	
	@Override
	public int getLength() {
		return Math.addExact(firstLeg.getLength(), continuation.getLength());
	}
	
	public Road getFirstLeg() { return firstLeg; }
	
	public Route getContinuation() { return continuation; }
	
	@Override
	public City getEndCity() {
		return continuation.getEndCity();
	}
	
	public NonemptyRoute(City startCity, Road firstLeg, Route continuation) {
		super(startCity);
		if (firstLeg == null)
			throw new IllegalArgumentException("firstLeg is null");
		if (continuation == null)
			throw new IllegalArgumentException("continuation is null");
		if (!firstLeg.getCities().equals(Set.of(startCity, continuation.getStartCity())))
			throw new IllegalArgumentException("firstLeg does not connect startCity and continuation's start city");
		this.firstLeg = firstLeg;
		this.continuation = continuation;
	}
	
	@Override
	public boolean equals(Object other) {
		if (!super.equals(other))
			return false;
		NonemptyRoute otherRoute = (NonemptyRoute)other;
		return firstLeg.equals(otherRoute.getFirstLeg()) && continuation.equals(otherRoute.getContinuation());
	}

	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), firstLeg, continuation);
	}
	
}
