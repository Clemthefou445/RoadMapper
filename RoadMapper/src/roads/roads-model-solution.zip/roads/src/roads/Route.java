package roads;

public abstract class Route {
	
	private final City startCity;
	
	public City getStartCity() { return startCity; }
	
	public abstract int getLength();
	
	public abstract City getEndCity();
	
	Route(City startCity) {
		if (startCity == null)
			throw new IllegalArgumentException("startCity is null");
		this.startCity = startCity;
	}

	@Override
	public int hashCode() {
		return startCity.hashCode();
	}

	@Override
	public boolean equals(Object otherObject) {
		if (this == otherObject)
			return true;
		if (otherObject == null)
			return false;
		if (getClass() != otherObject.getClass())
			return false;
		Route other = (Route)otherObject;
		return startCity.equals(other.startCity);
	}
	
}