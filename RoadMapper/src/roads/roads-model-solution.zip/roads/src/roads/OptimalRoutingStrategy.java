package roads;

public class OptimalRoutingStrategy implements RoutingStrategy {

	/**
	 * @throws IllegalArgumentException | from == null
	 * @throws IllegalArgumentException | to == null
	 * @inspects | this, from, to
	 * @post | result == null ?
	 *       |     from.getRoutesTo(to).findAny().isEmpty()
	 *       | :
	 *       |     result.getStartCity() == from && result.getEndCity() == to &&
	 *       |     from.getRoutesTo(to).allMatch(route -> route.getLength() >= result.getLength())
	 */
	public Route getRoute(City from, City to) {
		if (from == null)
			throw new IllegalArgumentException("from is null");
		if (to == null)
			throw new IllegalArgumentException("to is null");
		return from.getRoutesTo(to).min((r1, r2) -> r1.getLength() - r2.getLength()).orElse(null);
	}
	
}
