package roads;

public class EmptyRoute extends Route {

	@Override
	public int getLength() {
		return 0;
	}
	
	@Override
	public City getEndCity() {
		return getStartCity();
	}
	
	public EmptyRoute(City startCity) {
		super(startCity);
	}
	
}
