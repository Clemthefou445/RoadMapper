package roads;

public class FastRoutingStrategy implements RoutingStrategy {

	/**
	 * @pre | from != null
	 * @pre | to != null
	 * @inspects | this, from, to
	 * @post | result == null ?
	 *       |     from.getRoutesTo(to).findAny().isEmpty()
	 *       | :
	 *       |     result.getStartCity() == from && result.getEndCity() == to
	 */
	public Route getRoute(City from, City to) {
		return from.getRoutesTo(to).findAny().orElse(null);
	}
	
}
