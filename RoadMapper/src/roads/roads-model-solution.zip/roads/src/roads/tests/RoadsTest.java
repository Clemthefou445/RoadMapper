package roads.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;

import roads.City;
import roads.EmptyRoute;
import roads.FastRoutingStrategy;
import roads.NonemptyRoute;
import roads.OptimalRoutingStrategy;
import roads.Road;

class RoadsTest {

	City cityA = new City("CityA");
	City cityB = new City("CityB");
	City cityC = new City("CityC");
	City cityD = new City("CityD");
	
	Road roadAB = new Road(Set.of(cityA, cityB), 10);
	Road roadBC = new Road(Set.of(cityB, cityC), 20);
	Road roadAD = new Road(Set.of(cityA, cityD), 15);
	Road roadDC = new Road(Set.of(cityD, cityC), 25);
	
	EmptyRoute routeCC = new EmptyRoute(cityC);
	NonemptyRoute routeBC = new NonemptyRoute(cityB, roadBC, routeCC);
	NonemptyRoute routeABC = new NonemptyRoute(cityA, roadAB, routeBC);
	NonemptyRoute routeDC = new NonemptyRoute(cityD, roadDC, routeCC);
	NonemptyRoute routeADC = new NonemptyRoute(cityA, roadAD, routeDC);
	
	@Test
	void testRoads() {
		City cityA = new City("City1");
		assertEquals("City1", cityA.getName());
		assertEquals(Set.of(), cityA.getRoads());
		
		City cityB = new City("City2");
		City cityC = new City("City3");
		
		Road roadAB = new Road(Set.of(cityA, cityB), 10);
		assertEquals(Set.of(cityA, cityB), roadAB.getCities());
		assertEquals(10, roadAB.getLength());
		assertEquals(Set.of(roadAB), cityA.getRoads());
		assertEquals(Set.of(roadAB), cityB.getRoads());
		
		Road roadBC = new Road(Set.of(cityB, cityC), 20);
		assertEquals(Set.of(roadAB, roadBC), cityB.getRoads());
		assertEquals(Set.of(roadBC), cityC.getRoads());
	}
	
	@Test
	void testRoutes() {
		assertEquals(cityC, routeCC.getStartCity());
		assertEquals(0, routeCC.getLength());
		assertEquals(cityC, routeCC.getEndCity());
		
		assertEquals(cityB, routeBC.getStartCity());
		assertEquals(roadBC, routeBC.getFirstLeg());
		assertEquals(routeCC, routeBC.getContinuation());
		assertEquals(20, routeBC.getLength());
		assertEquals(cityC, routeBC.getEndCity());
		
		assertEquals(cityA, routeABC.getStartCity());
		assertEquals(roadAB, routeABC.getFirstLeg());
		assertEquals(routeBC, routeABC.getContinuation());
		assertEquals(30, routeABC.getLength());
		assertEquals(cityC, routeABC.getEndCity());
	}
	
	@Test
	void testRoutesTo() {
		assertEquals(Set.of(routeABC, routeADC), cityA.getRoutesTo(cityC).collect(Collectors.toSet()));
	}
	
	@Test
	void testRoutingStrategies() {
		assertTrue(Set.of(routeABC, routeADC).contains(new FastRoutingStrategy().getRoute(cityA, cityC)));
		assertEquals(routeABC, new OptimalRoutingStrategy().getRoute(cityA, cityC));
	}

}