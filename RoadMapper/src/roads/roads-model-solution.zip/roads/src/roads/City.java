package roads;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import logicalcollections.LogicalSet;

/**
 * @invar | getName() != null
 * @invar | getRoads() != null
 * @invar | getRoads().stream().allMatch(road -> road != null && road.getCities().contains(this))
 */
public class City {
	
	/**
	 * @invar | name != null
	 * @invar | roads != null
	 * @invar | roads.stream().allMatch(road -> road != null && road.cities.contains(this))
	 */
	final String name;
	/**
	 * @representationObject
	 * @peerObjects
	 */
	final Set<Road> roads = new HashSet<Road>();
	
	/** @immutable */
	public String getName() { return name; }
	/**
	 * @creates | result
	 * @peerObjects
	 * @basic
	 */
	public Set<Road> getRoads() { return Set.copyOf(roads); }
	
	/**
	 * @throws IllegalArgumentException | name == null
	 * @mutates | this
	 * @post | getName().equals(name)
	 * @post | getRoads().isEmpty()
	 */
	public City(String name) {
		if (name == null)
			throw new IllegalArgumentException("name is null");
		
		this.name = name;
	}
	
	public Stream<Route> getRoutesTo(City endCity) {
		return getRoutesTo(endCity, Set.of());
	}
	
	/** @pre | !excludedCities.contains(endCity) // optional precondition */
	Stream<Route> getRoutesTo(City endCity, Set<City> excludedCities) {
		if (endCity == this)
			return Stream.of(new EmptyRoute(endCity));
		Set<City> newExcludedCities = LogicalSet.plus(excludedCities, this);
		return roads.stream().flatMap(road -> {
			City nextCity = road.getOtherCity(this);
			if (!newExcludedCities.contains(nextCity)) {
				return nextCity.getRoutesTo(endCity, newExcludedCities).map(cont -> new NonemptyRoute(this, road, cont));
			} else
				return Stream.empty();
		});
	}

}
