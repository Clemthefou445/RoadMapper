package roads;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import logicalcollections.LogicalSet;

/**
 * @invar | getCities() != null
 * @invar | getCities().size() == 2
 * @invar | getCities().stream().allMatch(city -> city != null && city.getRoads().contains(this))
 * @invar | getLength() > 0
 */
public class Road {
	
	public static Map<City, Set<Road>> getRoadsMap(Set<City> cities) {
		return cities.stream().collect(Collectors.toMap(city -> city, city -> city.getRoads()));
	}
	
	/**
	 * @invar | cities != null
	 * @invar | cities.size() == 2
	 * @invar | cities.stream().allMatch(city -> city != null && city.roads.contains(this))
	 * @invar | length > 0
	 * 
	 * @representationObject
	 * @peerObjects
	 */
	final Set<City> cities;
	final int length;

	/**
	 * @creates | result
	 * @peerObjects
	 * @immutable
	 */
	public Set<City> getCities() { return cities; }
	/**
	 * @immutable
	 */
	public int getLength() { return length; }
	
	public City getOtherCity(City city) {
		return cities.stream().filter(city0 -> city0 != city).findAny().get();
	}
	
	/**
	 * @throws IllegalArgumentException | cities == null
	 * @throws IllegalArgumentException | cities.size() != 2
	 * @throws IllegalArgumentException | cities.stream().anyMatch(city -> city == null)
	 * @throws IllegalArgumentException | length <= 0
	 * @inspects | cities
	 * @mutates | this
	 * @mutates_properties | (...cities).getRoads()
	 * @post | getCities().equals(cities)
	 * @post | getLength() == length
	 * @post | cities.stream().allMatch(city ->
	 *       |     city.getRoads().equals(LogicalSet.plus(old(getRoadsMap(cities)).get(city), this)))
	 */
	public Road(Set<City> cities, int length) {
		if (cities == null)
			throw new IllegalArgumentException("cities is null");
		if (cities.size() != 2)
			throw new IllegalArgumentException("exactly two cities expected");
		if (cities.stream().anyMatch(city -> city == null))
			throw new IllegalArgumentException("cities contains null");
		if (length <= 0)
			throw new IllegalArgumentException("length not greater than zero");
		
		this.cities = Set.copyOf(cities);
		for (City city : cities)
			city.roads.add(this);
		this.length = length;
	}
	
}
